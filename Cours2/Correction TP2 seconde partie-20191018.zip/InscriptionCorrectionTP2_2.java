package tp2_2019;

import java.util.Scanner;

public class InscriptionCorrectionTP2_2 {
	
	/**************** Attributs **********************/
	private int codeInscription;
	private int codePays;
	
	
	/***************Constructeurs ********************/
	public InscriptionCorrectionTP2_2() {
		
	}
	
	
	public InscriptionCorrectionTP2_2(int codeI, int codeP) {
		this.setCodeInscription(codeI);;
		this.setCodePays(codeP);
	}
	
	
	/******************Accesseurs *********************/
	public int getCodeInscription() {
		return codeInscription;
	}
	public void setCodeInscription(int codeI) {
		if (codeI == 1 || codeI==2 ) this.codeInscription = codeI;
		else {
			System.out.println("Erreur ! Le code d'inscription doit être 1 ou 2");
		}
	}
	public int getCodePays() {
		return codePays;
	}
	public void setCodePays(int codeP) {
		if (codeP == 1 || codeP==2 || codeP==3) this.codePays = codeP;
		else {
			System.out.println("Erreur ! Le code pays doit être 1, 2 ou 3");
		}

	}
	
	/************Methode ToString ******************/
	 public String toString() {
			return "Inscription: " + this.typeInscription() + ", nationalite: " + this.nationalite();
		} 
	
	 /***********Autres méthodes*******************/
	 
	 /* Méthode nationalité qui retourne la nationalité de l'étudiant */
		public String nationalite()
		{
			if (this.getCodePays() ==1) return "étudiant français";
			else if (this.getCodePays() == 2) return "étudiant étranger non francophone";
			else if (this.getCodePays()==3) return "étudiant étranger francophone"; 
			else return "pas de nationalité renseignée";
		}
		
		/* Méthode nationalité qui retourne la nationalité de l'étudiant */
		public String typeInscription()
		{
			if (this.getCodeInscription() ==1) return "première inscription";
			else if (this.getCodeInscription()==2) return "réinscription"; 
			else return "pas d'information sur le nombre d'inscription";
		}
		
		
		// Methode saisie
		public void saisie(Scanner sc) {
			System.out.println("Veuillez saisir le code inscription : 1 pour une première inscription et 2 pour une réinscription");
			this.setCodeInscription(sc.nextInt());
			System.out.println("Veuillez saisir le code de la nationalité : 1 pour français, 2 pour étranger non francophone et 3 pour étranger francophone");
			this.setCodePays(sc.nextInt());
		}
		

}
